const { pool } = require('../../config/database');

/**
 * <summary>
 * Add or update a cart item. If the product already exists in the cart, increment its quantity.
 * </summary>
 * <param name="data">Cart payload containing userid, guestcartid, productid, qty, and createdby.</param>
 * <returns>Promise resolving to the inserted or updated cart row.</returns>
 */
exports.addToCart = async (data) => {
const { userid, guestcartid, productid, qty, createdby } = data;

  const checkSql = `
    SELECT cartid, qty
    FROM tbcart
    WHERE (userid = $1
      OR guestcartid = $2)
      AND productid = $3
      AND delflag = 0
  `;

  const { rows } = await pool.query(checkSql, [userid, guestcartid, productid]);

  if (rows.length > 0) {
    const updateSql = `
      UPDATE tbcart
      SET qty = qty + $1,
          modifiedby = $2,
          modifiedon = NOW()
      WHERE cartid = $3
      RETURNING *
    `;
    const result = await pool.query(updateSql, [
      qty,
      createdby,
      rows[0].cartid
    ]);
    return result.rows[0];
  }

  const insertSql = `
    INSERT INTO tbcart
      (userid, guestcartid, productid, qty, createdby, createdon, delflag, modifiedby, deletedby)
    VALUES
      ($1, $2, $3, $4, $5, NOW(), 0, 0, 0)
    RETURNING *
  `;

  const result = await pool.query(insertSql, [
    userid,
    guestcartid,
    productid,
    qty,
    createdby
  ]);

  return result.rows[0];
};

/**
 * <summary>
 * Retrieve the current cart items for a user or guest session.
 * </summary>
 * <param name="userid">User identifier.</param>
 * <param name="guestcartid">Optional guest cart identifier.</param>
 * <returns>Promise resolving to the cart item list.</returns>
 */
exports.getCartByUserId = async (userid, guestcartid) => {
  const sql = `SELECT
                  c.cartid,
                  c.qty,
                  p.productid,
                  p.productname,
                  ROUND(COALESCE(pp.mrp, 0), 2) AS marketprice,
                  ROUND(COALESCE(pp.wholesaleprice, 0), 2) AS dealprice,
                  ROUND(COALESCE(pp.mrp, 0) - COALESCE(pp.wholesaleprice, 0), 2) AS saveprice,
                  COALESCE(pi.imagepath, '/images/default.jpg') AS image,
                  pi.ishasclude,
                  COALESCE(pi.cludeimagepath, '/images/default.jpg') AS cludeimage,

                  -- Base amount
                  ROUND((COALESCE(pp.wholesaleprice, 0) * c.qty), 2) AS totalamount,

                  -- Tax Info
                  COALESCE(t.taxname, 'No Tax') AS taxname,
                  ROUND(COALESCE(t.taxpercentage, 0), 2) AS taxpercentage,

                  -- Tax Amount
                  ROUND(((COALESCE(pp.wholesaleprice, 0) * c.qty) 
                      * COALESCE(t.taxpercentage, 0) / 100), 2) AS taxamount,

                  -- Final Amount (with tax)
                  ROUND((
                      (COALESCE(pp.wholesaleprice, 0) * c.qty) +
                      ((COALESCE(pp.wholesaleprice, 0) * c.qty) 
                      * COALESCE(t.taxpercentage, 0) / 100)
                  ), 2) AS finalamount
                FROM tbcart c
                  JOIN tbproduct p 
                      ON p.productid = c.productid
                  LEFT JOIN tbproductprice pp 
                      ON pp.productid = p.productid
                  LEFT JOIN tbproductimage pi
                      ON pi.productid = p.productid 
                      AND pi.isprimary = true
                  LEFT JOIN tbcategory cat
                      ON cat.categoryid = p.categoryid
                      AND cat.isactive = true
                      AND cat.delflag = 0
                  LEFT JOIN tbtax t
                      ON t.taxid = cat.taxid
                      AND t.isactive = true
                      AND t.delflag = false
                  WHERE 
                      (c.userid = $1
                      OR c.guestcartid = $2)
                      AND c.delflag = 0;
  `;

  const { rows } = await pool.query(sql, [userid, guestcartid]);
  return rows;
};


/**
 * <summary>
 * Calculate the applicable discount rule for a user based on completed orders.
 * </summary>
 * <param name="userid">User identifier.</param>
 * <returns>Promise resolving to order count, rule type, and discount percentage.</returns>
 */
exports.getUserDiscountRule = async (userid) => {

  /* =========================================
   * 1. GET USER ORDER COUNT
   * ========================================= */
  const orderCountSql = `
    SELECT COUNT(*) AS total_orders
    FROM tborder
    WHERE userid = $1
      AND delflag = 0;
  `;

  const orderResult = await pool.query(orderCountSql, [userid]);
  const orderCount = parseInt(orderResult.rows[0].total_orders, 10);

  /* =========================================
   * 2. FETCH ACTIVE RULES (PRIORITY ORDER)
   * ========================================= */
  const rulesSql = `
    SELECT *
    FROM discount_rules
    WHERE is_active = TRUE
      AND (valid_from IS NULL OR valid_from <= NOW())
      AND (valid_to IS NULL OR valid_to >= NOW())
    ORDER BY priority ASC;
  `;

  const { rows: rules } = await pool.query(rulesSql);

  /* =========================================
   * 3. APPLY RULE ENGINE
   * ========================================= */
  let matchedRule = null;

  for (const rule of rules) {

    switch (rule.rule_type) {

      case 'FIRST_ORDER':
        if (orderCount === 0) {
          matchedRule = rule;
        }
        break;

      case 'ORDER_COUNT':
        if (
          (rule.min_orders === null || orderCount >= rule.min_orders) &&
          (rule.max_orders === null || orderCount <= rule.max_orders)
        ) {
          matchedRule = rule;
        }
        break;

      case 'DEFAULT':
        matchedRule = rule;
        break;
    }

    if (matchedRule) break;
  }

  /* =========================================
   * 4. RETURN RESULT
   * ========================================= */
  return {
    orderCount,
    rule: matchedRule ? matchedRule.rule_type : null,
    discount: matchedRule ? Number(matchedRule.discount_percent) : 0
  };
};

/**
 * <summary>
 * Update the quantity of an existing cart item.
 * </summary>
 * <param name="cartid">Cart item identifier.</param>
 * <param name="qty">New quantity value.</param>
 * <param name="modifiedby">User ID updating the cart item.</param>
 * <returns>Promise resolving to the updated cart row.</returns>
 */
exports.updateCartQty = async (cartid, qty, modifiedby) => {
  if (qty <= 0) throw new Error('Invalid quantity');

  const sql = `
    UPDATE tbcart
    SET qty = $1,
        modifiedby = $2,
        modifiedon = NOW()
    WHERE cartid = $3
      AND delflag = 0
    RETURNING *;
  `;

  const { rows } = await pool.query(sql, [
    qty,
    modifiedby,
    cartid
  ]);

  return rows[0];
};

/**
 * <summary>
 * Bulk update quantities for multiple cart items.
 * </summary>
 * <param name="items">Array of {cartid, qty} objects.
 * </param>
 * <param name="modifiedby">User ID performing the bulk update.</param>
 * <returns>Promise resolving to true once updates are committed.</returns>
 */
exports.updateCartBulk = async (items, modifiedby) => {
  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    for (const item of items) {
      if (!item.cartid || item.qty < 1) continue;

      const sql = `
        UPDATE tbcart
        SET qty = $1,
            modifiedby = $2,
            modifiedon = NOW()
        WHERE cartid = $3
          AND delflag = 0;
      `;

      await client.query(sql, [item.qty, modifiedby, item.cartid]);
    }

    await client.query('COMMIT');
    return true;

  } catch (err) {
    await client.query('ROLLBACK');
    throw err;

  } finally {
    client.release();
  }
};

/**
 * <summary>
 * Soft delete a single cart item.
 * </summary>
 * <param name="cartid">Cart item identifier.</param>
 * <param name="deletedby">User ID performing the deletion.</param>
 * <returns>Promise resolving to true if the item was deleted.</returns>
 */
exports.deleteCartItem = async (cartid, deletedby) => {
  const sql = `
    UPDATE tbcart
    SET delflag = 1,
        deletedby = $2,
        deletedon = NOW()
    WHERE cartid = $1
      AND delflag = 0
    RETURNING cartid;
  `;

  const { rows } = await pool.query(sql, [cartid, deletedby]);

  return rows.length > 0;
};